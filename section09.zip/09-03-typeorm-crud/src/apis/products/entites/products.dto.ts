// create-products.dto.ts
export class CreateProductsDto {
    name: string;
    description: string;
    price: number;
  }