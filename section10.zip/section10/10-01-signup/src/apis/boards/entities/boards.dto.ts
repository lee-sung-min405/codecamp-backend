// create-board.dto.ts
export class CreateBoardDto {
    writer: string;
    title: string;
    contents: string;
  }