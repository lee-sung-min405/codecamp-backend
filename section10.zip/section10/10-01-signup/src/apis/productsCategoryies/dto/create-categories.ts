// create-categories.input.ts
export class CreateCategoriesDto {
    name: string;
  }